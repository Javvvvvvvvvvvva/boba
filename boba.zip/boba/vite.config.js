export default {
  root: '.', // 👈 now using root directory
  base: './',
  build: {
    outDir: 'dist',
    emptyOutDir: true
  },
  plugins: [],
  assetsInclude: ['**/*.glb']
}

